# DP-YAMO 系统架构文档

> 技能名: `dp-yamo` | Python 包: `yamo` + `reactnet.config`
> 生成日期: 2026-08-01

---

## 1. 系统总览

DP-YAMO 是**分子分析与量子化学计算工具集**，提供从 SMILES 解析到 XTB/DFT 计算的完整链路。

| 层级 | 组成 | 职责 |
|------|------|------|
| **Skill 层** | SKILL.md + 5 reference 文档 | 工作流路由、Mira compute 提交规则、本地计算编排 |
| **Python 包层** | `yamo` (yamol + wrappers + workflows) | 分子表示、量子化学包装器、计算工作流 |
| **Mira Compute** | `crest_sampling`, `bp_hvap`, `volcqc_redox_calc` 等 | 云端 CREST 构象采样、COSMO-RS BP/Hvap、DFT 计算 |

**计算级别**: XTB (GFN2/g-xTB) / DFT (VOLCQC/gpu4pyscf) / MLIP (MACE/ORB/UMA)

---

## 2. 文件架构

### Skill 目录 (`/app/skills/dp-yamo/`)

```
dp-yamo/
├── SKILL.md                          # 主入口: 预飞检查、Mira compute 提交规则、wrapper 总表
└── references/
    ├── API.md                         # (50KB) 完整 API 参考
    ├── BEST_PRACTICE.md               # 计算设置模式、批量工作流、故障排除
    ├── VOLCQC.md                      # (26KB) 云端 GPU DFT wrapper 文档
    ├── WORKFLOWS.md                   # (18KB) 高级工作流和完整示例
    └── dft_redox_config.yaml          # 氧化还原工作流配置模板
```

### Python 包 (`yamo`)

核心类与函数:

| 模块/类 | 说明 |
|----------|------|
| `yamol` | 核心分子类: SMILES→3D、电荷/多重度、优化、构象采样、性质评估 |
| `XTB` | xTB 包装器: opt, sp, 热化学, 溶剂 |
| `VOLCQC` | 云端 GPU DFT: sp, opt, TS, IRC, 密度/轨道可视化 |
| `CREST` | 本地 CREST MTD 构象采样 |
| `PYSIS` | Pysisyphus 优化器 (TS, IRC) |
| `PYGSM` | Growing String Method 反应路径 |
| **workflows** | |
| `volcqc_redox_calc` | DFT 氧化还原电位 CLI |
| `xtb_redox_calc` | xTB 氧化还原电位 CLI |
| `li_complex_sampling` | Li 电解液配合物采样 CLI |

---

## 3. 核心 API

### 3.1 yamol (分子对象)

```python
from yamo import yamol
mol = yamol("CCO")   # SMILES, xyz/mol 文件, RDKit Mol, 或 (adj_mat, geo, elements, charge)

mol.elements   # ['C','C','O','H',...]
mol.geo        # N×3 坐标 (Å)
mol.q          # 总电荷
mol.unpair     # 未配对电子数 → multiplicity = unpair + 1
mol.energy     # 最后 opt/conf_sample 后的能量 (Hartree)
mol.confs      # conf_sample 后的构象列表

# 计算
mol.opt()                                     # XTB 优化
mol.opt(calculator="volcqc", functional="b3lyp", basis="def2-svp")  # DFT
mol.conf_sample(method="crest", quick_mode="quick")                 # CREST 构象
mol.evaluate("energy")                                               # XTB SP
mol.evaluate("redox", method="xtb", solvent="h2o")                   # ET 氧化还原
mol.evaluate("redox_pcet", method="xtb", pcet_mode="reduction", pH=7.0) # PCET

# 格式转换
mol.to_xyz("out.xyz"); mol.to_mol("out.mol"); mol.to_smiles(); mol.to_inchikey()
```

### 3.2 Wrapper 基模式

```python
wrapper = WrapperClass(..., charge=q, multiplicity=mult, nproc=N)
wrapper.execute()
if wrapper.calculation_terminated_normally():
    E, G = wrapper.get_final_structure()   # (elements, geometry)
```

### 3.3 Wrapper 总表

| 类型 | Wrapper | 用途 | 计算器 |
|------|---------|------|--------|
| SQM | XTB | 快速优化/能量/频率 | `lot='gxtb'`(默认), `gfn2`, `gfn0/1`, `gfnff` |
| DFT | VOLCQC | GPU DFT (sp/opt/TS/IRC/密度) | `functional=`, `basis=` (需 `load_molecules`) |
| 构象 | CREST | MTD 构象采样 | `quick_mode='quick'/'squick'/'vquick'/'none'` |
| 构象 | CONFAB | 快速键旋转 | |
| 优化 | PYSIS | Pysisyphus 优化器 | `calctype='gxtb'/'xtb'/'pyscf'/'mlff-*'` |
| MEP | PYGSM | GSM 反应路径 | `calc='gxtb'` → GxtbSubprocessCalculator |

### 3.4 Mira Compute 类型

| compute_type | 任务 | 典型时间 |
|-------------|------|---------|
| `crest_sampling` | 3D 构象生成 | 5 min – 2 hr/molecule |
| `bp_hvap` | COSMO-RS BP/Hvap | 10–60 min/molecule |

---

## 4. 内置工作流

```
                    ┌─ 3D结构/CREST → crest_sampling (Mira)
                    ├─ BP/Hvap     → bp_hvap (Mira)
用户任务 ──→ SKILL.md ├─ 氧化还原    → volcqc_redox_calc / xtb_redox_calc
                    ├─ Li配合物    → li_complex_sampling sample
                    └─ 自定义      → 预飞 Q1-4 → 脚本→nohup→轮询
```

**Mira compute 提交六步**:
1. 写一个 CSV 输入文件
2. `compute_submit` 一次 (不循环)
3. 稳定 `idempotency_key`
4. 报告 job_id
5. `compute_get_status` 轮询 (自适应 sleep)
6. `compute_sync_results` 后读取结果

---

## 5. 调用关系图

```
用户输入 (SMILES/名称)
    │
    ├─→ yamol() → 3D 结构
    │
    ├─→ 内置工作流路由
    │   ├── Mira: compute_submit → compute_get_status → compute_sync_results
    │   └── 本地: nohup python -u script.py & → PID轮询
    │
    └─→ 包装器
        ├── XTB: xtb 二进制 subprocess
        ├── VOLCQC: Volcengine QC REST API (gpu4pyscf)
        ├── CREST: crest 二进制 subprocess
        ├── PYSIS/PYGSM: pysisyphus/pygsm 引擎
        └── MLIP: MACE/ORB/UMA 模型推理
```

## 6. 错误处理

```python
wrapper.execute()
if wrapper.calculation_terminated_normally():
    E, G = wrapper.get_final_structure()
else:
    print(f"WARNING: Calculation failed for {wrapper.jobname}")
```

**VOLCQC 特殊**: `pysisyphus` 任务类型必须 `pysis = volcqc.get_pysis(name)` 然后 `pysis.get_energy()`。

## 附录: 关键约束

- `yamol` 不接受 CAS/IUPAC/PDB；仅 SMILES, 文件路径, RDKit Mol, 或 (adj_mat, geo, elements, charge)
- DFT 仅通过 VOLCQC (gpu4pyscf)；禁止 ORCA/PySCF/Gaussian
- 构象采样强制启用 (skip 导致 GSM 频繁失败)
- 电荷/多重度必须从 `yamol` 派生 (`mol.q`, `mol.unpair+1`)
- VOLCQC 批量优化: 所有分子一批 `load_molecules + 一次 execute`
